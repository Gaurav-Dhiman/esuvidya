<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Student extends CI_Controller {
		
	/**
	 * Default Constructor
	 */
	function __construct(){
		parent::__construct();	
		$this->load->model('model_student');	
		$this->load->library('datatables');		
	}	

	/**
	 * @author Gaurav Dhiman.
	 * @method index	
	 */
	public function index()
	{
		//pre_print('herhe');
		superadmin_view('student');
	}
	
	/**
	 * @author Gaurav Dhiman.
	 * @method add	
	 */
	public function add()
	{
		if(isset($_POST['submit']) && !empty($_POST)):
			//pre_print($_POST);
			$arrData = array();
			$arrData = copy_posted($arrData,
							array(
								'gr_num','roll_num','std','stream','division','semester','admit_to','medium','fname','mname','lname','mother_name',
								'adrs_residence','adrs_father_ofc','adrs_mother_ofc','adrs_native','city','pincode','district','birth_place',
								'phone','mobile','alt_phone','gender','religion','caste','s_caste','weight','height','birth_date','admission_date',
								'fee_scheme','start_std','blood_grp','status','father_occupation','mother_occupation','mother_tongue',	
								'nationality','near_rly_stn','seat_num','child_num','passed_out'
								,'last_percentage','handicap','nss'		
							)
						);
			$arrData['created'] = date('y-m-d H:i:s');
			$arrData['modified'] = date('y-m-d H:i:s');
			$arrData['updated_by'] = "Gaurav Dhiman";					
			
			$response = $this->model_student->insert_new_student($arrData);
			pre_print($response);
			if($response > 0):
				redirect('student/listing');
			else:
				superadmin_view('add_student');
			endif;
		else:
			superadmin_view('student/add_student');			
		endif;
		
	}
	
	/**
	 * @author Gaurav Dhiman.
	 * @method edit student	
	 */
	public function edit($stud_id)
	{
		if(isset($_POST['submit']) && !empty($_POST)):
			//
			$arrData = array();
			$arrData = copy_posted($arrData,
							array(
								'gr_num','roll_num','std','stream','division','semester','admit_to','medium','fname','mname','lname','mother_name',
								'adrs_residence','adrs_father_ofc','adrs_mother_ofc','adrs_native','city','pincode','district','birth_place',
								'phone','mobile','alt_phone','gender','religion','caste','s_caste','weight','height','birth_date','admission_date',
								'fee_scheme','start_std','house','blood_grp','status','repeater','father_occupation','mother_occupation','mother_tongue',	
								'nationality','computer','books_allowed','near_rly_stn','seat_num','bus','bus_num','bus_route','child_num','passed_out'
								,'last_percentage','handicap','nss'		
							)
						);			
			$arrData['modified'] = date('y-m-d H:i:s');
			$arrData['updated_by'] = "Gaurav Dhiman";
			//pre_print($arrData);
			$response = $this->model_student->update_student($stud_id,$arrData);
			pre_print($response);
			if($response > 0):
				redirect('student/listing');
			else:
				superadmin_view('edit_student');
			endif;
		else:
			$arrData['student_details'] = $this->model_student->get_student($stud_id);
			//pre_print($arrData);
			superadmin_view('student/edit_student',$arrData);			
		endif;
		
	}
	
	/**
	 * @author Gaurav Dhiman.
	 * @method delete student
	 */
	public function delete($stud_id)
	{
		//pre_print($_POST);
		superadmin_view('student/student_listing');
	}
	
	
	/**
	 * @author Gaurav Dhiman.
	 * @method listing	
	 */
	public function listing()
	{
				
		superadmin_view('student/student_listing');
	}
	
	/**
	 * @author Gaurav Dhiman.
	 * @method Datatable function	
	 */
	function ajax_datatable_student_list(){
		
		echo $this->model_student->ajax_student_list();
		
	}
	
	/**
	 * @author Gaurav Dhiman.
	 * @method view function	
	 */
	public function view($stud_id){
				
		if(!empty($stud_id)):
			$arrData = array();
			$arrData['student_details'] = $this->model_student->get_student($stud_id);
			if(!empty($arrData['student_details'])):
				superadmin_view('student/view_student',$arrData);
			else:
				redirect('student/student_listing');
			endif;	
		else:
			redirect('student/student_listing');
		endif;	
						
	}
	
	/**
	 * @author Gaurav Dhiman.
	 * @method new student listing	
	 */
	public function new_student_listing()
	{
				
		superadmin_view('student/new_student_listing');
	}
	
	
	/**
	 * @author Gaurav Dhiman.
	 * @method Datatable function for new student listing
	 */
	function ajax_datatable_new_student_list(){
		
		echo $this->model_student->ajax_new_student_list();
		
	}
	
	/**
	 * @author Gaurav Dhiman.
	 * @method student by caste listing
	 */
	public function student_by_caste_listing()
	{
				
		superadmin_view('student/student_by_caste_listing');
	}
	
	
	/**
	 * @author Gaurav Dhiman.
	 * @method Datatable function for student by caste listing
	 */
	function ajax_datatable_student_by_caste_list(){
		
		echo $this->model_student->ajax_student_by_caste_list();  
		
	}
	
	
	/**
	 * @author Gaurav Dhiman.
	 * @method student by age listing
	 */
	public function student_by_age_listing()
	{
				
		superadmin_view('student/student_by_age_listing');
	}
	
	
	/**
	 * @author Gaurav Dhiman.
	 * @method Datatable function for student by age listing
	 */
	function ajax_datatable_student_by_age_list(){
		
		echo $this->model_student->ajax_student_by_age_list();  
		
	}
	
	
	/**
	 * @author Gaurav Dhiman.
	 * @method student by Birthday listing
	 */
	public function student_by_birthday_listing()
	{
				
		superadmin_view('student/student_by_birthday_listing');
	}
	
	
	/**
	 * @author Gaurav Dhiman.
	 * @method Datatable function for student by Birthday listing
	 */
	function ajax_datatable_student_by_birthday_list(){
		
		echo $this->model_student->ajax_student_by_birthday_list();  
		
	}
	
	
	/**
	 * @author Gaurav Dhiman.
	 * @method student by Birthday listing
	 */
	public function student_by_class_listing()
	{
				
		superadmin_view('student/student_by_class_listing');
	}
	
	
	/**
	 * @author Gaurav Dhiman.
	 * @method Datatable function for student by class listing
	 */
	function ajax_datatable_student_by_class_list(){
		
		echo $this->model_student->ajax_student_by_class_list();  
		
	}
	
	/**
	 * @author Gaurav Dhiman.
	 * @method Bonefide 
	 */
	public function bonafide()
	{
				
		superadmin_view('student/bonafide');
	}
	
	/**
	 * @author Gaurav Dhiman.
	 * @method student by Birthday listing
	 */
	public function leaving_certificate()
	{
				
		superadmin_view('student/leaving_certificate');
	}
	
	
	
}
