
<div class="portlet box blue ">
	<div class="portlet-title">
		<div class="caption"><i class="icon-reorder"></i>Add Student</div>
		<div class="tools">
			<a href="javascript:;" class="collapse"></a>
			<a href="#portlet-config" data-toggle="modal" class="config"></a>
			<a href="javascript:;" class="reload"></a>
			<a href="javascript:;" class="remove"></a>
		</div>
	</div>
</div>
<div class="clear"></div>
<div class="container-fluid">
	<div class="new-form">
		<form action="<?php echo base_url('student/add');?>" class="form-horizontal form-bordered form-label-stripped" method="POST">
			<div class="row-fluid">
				<div class="span12">
					<!-- <div class="span3"><input name="idno" type="text" placeholder="ID No." class="m-wrap span12" /></div> -->
					<div class="span3"><label class="control-label">GR No.</label><input name="gr_num" type="text" placeholder="GR No." class="m-wrap span12" /></div>
					<div class="span3"><label class="control-label">Roll No</label><input name="roll_num" type="text" placeholder="Roll No" class="m-wrap span12" /></div>
					<div class="span3"><label class="control-label">Add Photo</label><input name="image" type="file" placeholder="Add Photo" class="m-wrap span12" /></div>
					<div class="span3"><div class="preview pull-right">Photo</div></div>
				</div>
			</div>
			<div class="row-fluid">
				<div class="span12">
					<div class="span3">
						<label class="control-label">std</label>
						<select name="std" class="m-wrap span12">
							<option value="">std</option>
							<option value="std1">std1</option>
							<option value="std2">std2</option>
						</select>
					</div>
					<div class="span3">
						<label class="control-label">Stream</label>
						<select name="stream" class="m-wrap span12">
							<option value="">Stream</option>
							<option value="stream1">stream1</option>
							<option value="stream2">stream2</option>
						</select>
					</div>
					<div class="span3">
						<label class="control-label">Division</label>
						<select name="division" class="m-wrap span12">
							<option value="">Division</option>
							<option value="division1">div1</option>
							<option value="division2">div2</option>
						</select>
					</div>
				</div>
			</div>
			<div class="row-fluid">
				<div class="span12">
					<div class="span3">
						<label class="control-label">Semester</label>
						<select name="semester" class="m-wrap span12">
							<option value="">Semester</option>
							<option value="semester1">semester1</option>
							<option value="semester2">semester2</option>
						</select>
					</div>
					<div class="span3">
						<label class="control-label">Admit To</label>
						<select name="admit to" class="m-wrap span12">
							<option value="">Admit To</option>
							<option value="2015-16">2015-16</option>
							<option value="2015-16">2015-16</option>
						</select>
					</div>
					<div class="span3">
						<label class="control-label">Medium</label>
						<select name="medium" class="m-wrap span12">
							<option value="">Meduim</option>
							<option value="english">English</option>
							<option value="hindi">Hindi</option>
						</select>
					</div>
				</div>
			</div>
			<div class="row-fluid">
				<div class="span12">
					<div class="span3"><label class="control-label">Last Name</label><input name="lname" type="text" placeholder="Last Name" class="m-wrap span12" /></div>
					<div class="span3"><label class="control-label">First Name</label><input name="fname" type="text" placeholder="First Name" class="m-wrap span12" /></div>
					<div class="span3"><label class="control-label">Middle Name</label><input name="mname" type="text" placeholder="Middle Name" class="m-wrap span12" /></div>
					<div class="span3"><label class="control-label">Mother's Name</label><input name="mother_name" type="text" placeholder="Mother's Name" class="m-wrap span12" /></div>
				</div>
			</div>
			<div class="row-fluid">
				<div class="span12">
					<div class="span3"><label class="control-label">Residence</label><textarea name="adrs_residence" class="m-wrap span12" placeholder="Residence"></textarea></div>
					<div class="span3"><label class="control-label">Father's Office Address</label><textarea name="adrs_father_ofc" class="m-wrap span12" placeholder="Father's Office Address"></textarea></div>
					<div class="span3"><label class="control-label">Mother's Office Address</label><textarea name="adrs_mother_ofc" class="m-wrap span12" placeholder="Mother's Office Address"></textarea></div>
					<div class="span3"><label class="control-label">Native Place Address</label><textarea name="adrs_native" class="m-wrap span12" placeholder="Native Place Address"></textarea></div>
				</div>
			</div>
			<div class="row-fluid">
				<div class="span12">
					<div class="span3">
						<label class="control-label">City</label>
						<select name="city" class="m-wrap span12">
							<option value="">City</option>
							<option value="dehradun">Dehradun</option>
							<option value="rishikesh">Rishikesh</option>
						</select>
					</div>
					<div class="span3"><label class="control-label">Pincode</label><input name="pincode" type="text" placeholder="Pincode" class="m-wrap span12" /></div>
					<div class="span3">
						<label class="control-label">District</label>
						<select name="district" class="m-wrap span12">
							<option value="">District</option>
							<option value="dehradun">Dehradun</option>
							<option value="haridwar">Haridwar</option>
						</select>
					</div>
					<div class="span3"><label class="control-label">Birth Place</label><input name="birth_place" type="text" placeholder="Birth Place" class="m-wrap span12"  /></div>
				</div>
			</div>
			<div class="row-fluid">
				<div class="span12">
					<div class="span3"><label class="control-label">Tel No.</label><input name="phone" type="text" placeholder="Tel No." class="m-wrap span12" /></div>
					<div class="span3"><label class="control-label">Tel No.</label><input name="mobile" type="text" placeholder="Tel No." class="m-wrap span12" /></div>
					<div class="span3"><label class="control-label">Tel No.</label><input name="alt_phone" type="text" placeholder="Tel No." class="m-wrap span12" /></div>
					<div class="span3">
						<label class="control-label">Gender</label>						
						<select name="gender" class="m-wrap span12">
							<option value="">Gender</option>
							<option value="Male">Male</option>
							<option value="Female">Female</option>							
						</select>
					</div>
				</div>
			</div>
			<div class="row-fluid">
				<div class="span12">
					<div class="span3">
						<label class="control-label">Religion</label>
						<select name="religion" class="m-wrap span12">
							<option value="">Religion</option>
							<option value="hindu">Hindu</option>
							<option value="muslim">Muslim</option>
						</select>
					</div>
					<div class="span3">
						<label class="control-label">Caste</label>
						<select name="caste" class="m-wrap span12">
							<option value="">Caste</option>
							<option value="OPEN">OPEN</option>
							<option value="SC">SC</option>
							<option value="ST">ST</option>
							<option value="OBC">OBC</option>
							<option value="SBC">SBC</option>
							<option value="NT">NT</option>
							<option value="VJNT">VJNT</option>
						</select>
					</div>
					<div class="span3"><label class="control-label">S-Caste</label><input name="s_caste" type="text" placeholder="S-Caste" class="m-wrap span12" /></div>
					<div class="span3">
						<label class="control-label">Weight</label><input name="weight" type="text" placeholder="Weight" class="m-wrap span6" /> 
						<label class="control-label">Height</label><input name="height" type="text" placeholder="Height" class="m-wrap span6" />
					</div>
				</div>
			</div>
			<div class="row-fluid">
				<div class="span12">					
					<div class="span3"><label class="control-label">Birth Date</label><input name="birth_date" type="text" placeholder="Birth Date" class="m-wrap span12" id="ui_date_picker_change_year_month" /></div>
				<!--<div class="span3"><input name="admission_date" type="text" placeholder="Admission Date" class="m-wrap span12" id="ui_date_picker_change_year_month" /></div>
					 <div class="span3">
						
						<select name="birth_date" class="m-wrap span12">
							<option value="">Birth Date</option>
							<option value="Female">sem</option>
						</select>
					</div> -->
					<div class="span3">
						<label class="control-label">Admission Date</label>
						<select name="admission_date" class="m-wrap span12">
							<option value="">Admission Date</option>
							<option value="date1">date1</option>
							<option value="date2">date2</option>
						</select>
					</div>
					<div class="span3"><label class="control-label">Fee Scheme</label><input name="fee_scheme" type="text" placeholder="Fee Scheme (click here for details)" class="m-wrap span12" /></div>
					<div class="span3">
						<label class="control-label">Start std.</label>
						<select name="start_std" class="m-wrap span12">
							<option value="">Start std.</option>
							<option value="std1">std1</option>
							<option value="std2">std2</option>
						</select>
					</div>
				</div>
			</div>
			
			<div class="row-fluid">
				<div class="span12">
					<div class="span3">
						<label class="control-label">Father Occupation</label>
						<select name="father_occupation" class="m-wrap span12">
							<option value="">Father Occupation</option>
							<option value="Service">Service</option>
							<option value="Business">Business</option>
							<option value="Professional">Professional</option>
							<option value="Other">Other</option>							
						</select>
					</div>
					<div class="span3">
						<label class="control-label">Mother Occupation</label>
						<select name="mother_occupation" class="m-wrap span12">
							<option value="">Mother Occupation</option>
							<option value="Housewife ">Housewife </option>
							<option value="Service">Service</option>
							<option value="Business">Business</option>
							<option value="Professional">Professional</option>
							<option value="Other">Other</option>
						</select>
					</div>
					<div class="span3">
						<label class="control-label">Mother Tongue</label>
						<select name="mother_tongue" class="m-wrap span12">
							<option value="">Mother Tongue</option>
							<option value="marathi">Marathi</option>
							<option value="gujrathi">Gujrathi</option>
						</select>
					</div>
					<div class="span3"><label class="control-label">Nationality</label><input name="nationality" type="text" placeholder="Nationality" class="m-wrap span12" /></div>
				</div>
			</div>
			<div class="row-fluid">
				<div class="span12">					
					<div class="span4">
						<label class="control-label">Blood Group</label>
						<select name="blood_grp" class="m-wrap span12">
							<option value="">Blood Group</option>
							<option value="A+">A+</option>
							<option value="A-">A-</option>
							<option value="B+">B+</option>
							<option value="B-">B-</option>
							<option value=" AB+"> AB+</option>
							<option value="AB-">AB-</option>
							<option value=" O+">O+</option>
							<option value="O-">O-</option>
						</select>
					</div>
					<div class="span4">
						<label class="control-label">Status</label>
						<select name="status" class="m-wrap span12">
							<option value="">Status</option>
							<option value="Current">Current</option>
							<option value="Left">Left</option>
							<option value="Finished">Finished</option>
							<option value="Long">Long</option>
							<option value="Absent">Absent</option>
							<option value="on_break">On break</option>
						</select>
					</div>
					<div class="span4">
						<label class="control-label">Passed Out</label>
						<select name="passed_out" class="m-wrap span12">
							<option value="">Passed Out</option>
							<option value="Year1">Year1</option>
							<option value="Year2">Year2</option>
						</select>
					</div>					
				</div>
			</div>
			<div class="row-fluid">
				<div class="span12">					
					<div class="span4"><label class="control-label">Near Railway Station</label><input name="near_rly_stn" type="text" placeholder="Near Railway Station" class="m-wrap span12" /></div>
					<div class="span4"><label class="control-label">Seat No.</label><input name="seat_num" type="text" placeholder="Seat No." class="m-wrap span12" /></div>
					<div class="span4"><label class="control-label">Child No.</label><input name="child_num" type="text" placeholder="Child No." class="m-wrap span12" /></div>
				</div>
			</div>			
			<div class="row-fluid">
				<div class="span12">					
					<div class="span4"><label class="control-label">Last %</label><input name="last_percentage" type="text" placeholder="Last %" class="m-wrap span12" /></div>
					<div class="span4"><label class="control-label">Handicap?</label><input name="handicap" type="text" placeholder="Handicap?" class="m-wrap span12" /></div>
					<div class="span4"><label class="control-label">N.S.S.?</label><input name="nss" type="text" placeholder="N.S.S.?" class="m-wrap span12" /></div>
					<input name="submit" type="hidden" value="submit"/>
				</div>
			</div>
			<div class="row-fluid">
				<div class="span12">
					
				</div>
			</div>
			<div class="row-fluid">
				<div class="span12">
					<div class="span1"><button type="submit" class="btn blue span12">Save (F5)</button></div>
					<div class="span2"><button type="submit" class="btn blue span12">Quick Student Entry</button></div>
					<div class="span2"><button type="submit" class="btn blue span12">Print GR Sheets</button></div>
					<div class="span2"><button type="submit" class="btn blue span12">Create new Record</button></div>
					<div class="span2"><button type="submit" class="btn blue span12">Admission Form</button></div>					
					<div class="span1"><button type="button" class="btn span12">Clear</button></div>
					<div class="span1"><button type="button" class="btn span12">Exit</button></div>
				</div>
			</div>
		</form>
	</div>
</div>	
<script>
	$(document).ready(function(){		
		UIJQueryUI.init();
	});
</script>				
	