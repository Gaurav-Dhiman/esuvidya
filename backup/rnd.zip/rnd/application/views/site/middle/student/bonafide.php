<?php
	//pre_print("Bonafide");
?>
<link href='https://fonts.googleapis.com/css?family=Tangerine:400,700' rel='stylesheet' type='text/css'>
<div class="container-fluid">
	<div class="row">
		<div class="span12">
			<div class="bonafide-header">
				<h5>Kalyan Education Society's</h5>
				<h2>Smt. Kantaben Chandulal Gandhi English School</h2>
				<h6>Gandhinagar, R.P. Road, Kalyan(W) - 421301. Tel: 2207745</h6>
				<h5>Secondary Section</h5>
				<h1>Bonafide Certificate</h1>
			</div>
			<div class="bonafide-content">
				<p class="certify">This is to certify that</p>
				<p>Miss Kundar Dakshata S is/was a bonafide <br/>
					student of this school and is studying in std. IX Div. C (Reg. No. 3910)<br/>
					She is regular in attendance.
				</p>
				<p>As per the school General register her date of birth is 15/07/1998 (Fifteenth July Nineteen Ninety Eight)</p>
				<p>Place of Birth: </p>
				<p>Caste &amp; Sub-Caste: </p>
				<p>To the best of my knowledge and belief she bears a good moral character and conduct.</p>
				<h6>Date: 06/08/2015</h6>
			</div>
		</div>
	</div>
</div>
